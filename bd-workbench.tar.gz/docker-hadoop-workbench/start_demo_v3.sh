#!/bin/bash

DOCKER_COMPOSE_FILE=docker-compose-v3.yml

SCRIPT_PATH=$(cd `dirname $0`; pwd)
docker-compose -f ${SCRIPT_PATH}/${DOCKER_COMPOSE_FILE} down
docker-compose -f ${SCRIPT_PATH}/${DOCKER_COMPOSE_FILE} pull
sleep 5

docker-compose -f ${SCRIPT_PATH}/${DOCKER_COMPOSE_FILE} up -d namenode datanode-1 datanode-2 datanode-3 resourcemanager nodemanager historyserver
sleep 5
docker-compose -f ${SCRIPT_PATH}/${DOCKER_COMPOSE_FILE} up -d hive-server hive-metastore hive-metastore-postgresql
sleep 5
docker-compose -f ${SCRIPT_PATH}/${DOCKER_COMPOSE_FILE} up -d spark-master spark-worker-1 spark-worker-2 spark-worker-3
sleep 15

docker exec -it namenode hdfs dfs -mkdir -p /user/spark/applicationHistory
docker-compose -f ${SCRIPT_PATH}/${DOCKER_COMPOSE_FILE} up -d spark-history-server
docker-compose -f ${SCRIPT_PATH}/${DOCKER_COMPOSE_FILE} up -d zeppelin

